<h1>Create new product</h1>
<?php include "_form.php"; ?>